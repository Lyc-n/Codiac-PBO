from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivy.lang import Builder

Builder.load_file("app/ui/splash.kv")
    
class SplashScreen(MDScreen):
  pass